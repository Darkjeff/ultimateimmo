dolibarr_place
==============

Module for Dolibarr ERP/CRM to manage plocation with buildings, floors and rooms
